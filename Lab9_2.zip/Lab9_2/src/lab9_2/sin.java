package lab9_2;
public class sin extends Taylor{
    public sin(int k ,double x){
        super.setIter(k);
        super.setValue(x);
    }
    @Override
    public void printValue() {
        double sum=0;
        for(int n=0;n<=super.getIter();n++){
            sum+=((Math.pow(-1, n))*(Math.pow(super.getValue(),(2*n)+1)))/super.factorial(2*n+1);
        }
        System.out.println("Value from Math.exp() is "+getApprox()+".");
        System.out.println("Approximated value is "+sum+".");

    }

    @Override
    public double getApprox() {
        return Math.sin(super.getValue());
    }

}