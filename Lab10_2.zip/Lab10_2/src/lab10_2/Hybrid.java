package lab10_2;
public class Hybrid extends Bus implements LiquidFuel,Electric{
    private double range;
    private int emissionTier;
    private double voltage;
    public Hybrid(int capacity,double cost,double voltage,double range,int emissionTier){
        super(capacity,cost);
        this.emissionTier=emissionTier;
        this.range=range;
        this.voltage=voltage;
        if(voltage<LOW_VOLTAGE){
            this.voltage=LOW_VOLTAGE;
        }
        else if(voltage>HIGH_VOLTAGE){
            this.voltage=HIGH_VOLTAGE;
        }
        else{
            this.voltage=voltage;
        }
    }
    @Override
    public double getAccel() {
        return 4.0;
    }

    @Override
    public double getRange() {
        return range;
    }

    @Override
    public int getEmissionTier() {
        return emissionTier;
    }

    @Override
    public double getVoltage() {
        return voltage;
    }
    
    
}
