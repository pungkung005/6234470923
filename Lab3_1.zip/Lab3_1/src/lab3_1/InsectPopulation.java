package lab3_1;
public class InsectPopulation {  
    private double insect;
    public InsectPopulation(double insect){  
        this.insect=insect;
    }
    public void breed(){
        insect=insect*2;
    }
    public void spary(){
        insect=insect*0.9;
    }
    public double getNumInsect(){
        return insect; 
    }
}