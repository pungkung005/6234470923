package lab3_1;
public class InsectPopulationTester {
    public static void main(String[] args) {
        InsectPopulation numinsect1= new InsectPopulation(10);
        numinsect1.breed();
        numinsect1.spary();
        System.out.println("Number of insects: "+numinsect1.getNumInsect());
        numinsect1.breed();
        numinsect1.spary();
        System.out.println("Number of insects: "+numinsect1.getNumInsect());
        numinsect1.breed();
        numinsect1.spary();
        System.out.println("Number of insects: "+numinsect1.getNumInsect());
    }
    
}