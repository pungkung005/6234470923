package lab12_2;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
public class Tester {
    private static String ans="";
    public static void main(String[] args) {
        try{
        Scanner input = new Scanner(System.in);
        File file =new File("/Users/prutprommart/NetBeansProjects/Lab12_3/src/wordlist.txt");
        Scanner rfile=new Scanner(file);
        System.out.print("Enter a sentence: ");
        String sentence=null;
        sentence=input.nextLine();
        System.out.println("Words not contained: ");
        String[] check=sentence.split(" ");
        ArrayList<String> word = new ArrayList<String>();
        while(rfile.hasNextLine()){
            word.add(rfile.nextLine());
        }
            for(int i=0;i<check.length;i++){
                for(int j =0;j<word.size();j++){
                    if(check[i].equals(word.get(j))){
                        break;
                    }
                    else if(j==word.size()-1){
                    ans=ans+check[i];
                    }
                }
            }
            if(ans.length()<1){
                ans="N/A";
            }
            System.out.println(ans);
            }
        catch(FileNotFoundException e){
           System.out.println (e);
    }
    
}
}
    
