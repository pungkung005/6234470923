
package lab3_3;

public class CashRegisterTester { 
 
     
    public static void main(String[] args) { 
        CashRegister crg = new CashRegister(7); 
        crg.recordPurchase(50); 
        crg.recordPurchase(10); 
        crg.recordTaxablePurchase(20); 
        crg.enterPayment(100); 
        System.out.printf("%.1f\n",crg.giveChange()); 
    } 
     
}