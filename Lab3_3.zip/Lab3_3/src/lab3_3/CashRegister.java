
package lab3_3;
    
public class CashRegister {
    public double input,total,fee;
    public CashRegister(double tax){
        fee=tax;
    }
    public void recordPurchase(double change){
        total+=change;
    }
    public void recordTaxablePurchase(double money){
        total=total+money*(100+fee)/100;
    }
    public double getTotalTax(){
        double tax=total*fee/100;
        return tax;
    }
    public void enterPayment(double amount){
        input+= amount;
    }
      public double giveChange(){ 
        double change = input-total ; 
        input = 0 ; 
        total = 0 ; 
         
        return change ; 
 
    } 
}