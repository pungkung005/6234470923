package lab5_1;

public class Zeller {

    private int month;
    private int year;
    private final int dayofmonth;
    private final int j;
    private final int k;
    private final int q;
    private final int m;
    
    public Zeller(int A, int B,int C){
        year=A;
        month=B;
        dayofmonth=C;
        if(month==1 || month==2){
            month+=12;
            year=year-1;
        }
        j=year/100;
        k=year%100;
        q=dayofmonth;
        m=month;
    }
    public enum Day{
        SUNDAY("Sunday"), MONDAY("Monday"),
TUESDAY("Tuesday"), WEDNESDAY("Wednesday"), THURSDAY("Thursday"),
FRIDAY("Friday"), SATURDAY("Saturday");
    private final String weekDay;
    private Day(String week){
        weekDay =week;
    }
    public String getWeekDay(){
        return weekDay;
    }
    }
    public Day getdayofweek(){
        Day day= null;
        int h = (q+((26*(m+1))/10)+k+(k/4)+(j/4)+(5*j))%7;
        
        switch(h){
            case 0:
                day=Day.SATURDAY;
                break;
            case 1:
                day=Day.SUNDAY;
                break;
            case 2:
                day=Day.MONDAY;
                break;
            case 3:
                day=Day.TUESDAY;
                break;
            case 4:
                day=Day.WEDNESDAY;
                break;
            case 5:
                day=Day.THURSDAY;
                break;
            case 6:
                day=Day.FRIDAY;
                break;
        }
        return day;
    }
    
}
