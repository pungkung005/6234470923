package lab5_1;

import java.util.Scanner;

public class Zellertester {

    public static void main(String[] args) {
        Scanner date= new Scanner(System.in);
        System.out.print("Enter year (e.g., 2012): ");
        int year =date.nextInt();
        System.out.print("Enter month (1-12): ");
        int month=date.nextInt();
        System.out.print("Enter day of the month (1-31): ");
        int dayofmonth=date.nextInt();
        Zeller zeller=new Zeller(year,month,dayofmonth);
        System.out.println("Day od the week is "+zeller.getdayofweek());
    }
    
}
