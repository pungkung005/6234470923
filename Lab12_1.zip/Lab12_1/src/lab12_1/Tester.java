package lab12_1;
import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
public class Tester {
    private static int word=0;
    private static int cha=0;
    private static int line=0;
    private static String i=null;
    public static void main(String[] args) throws Exception {
         Scanner input = new Scanner(System.in);
         File file =new File("lab12.txt");
         PrintWriter output=new PrintWriter(file);
         String sentence=null;
         sentence=input.nextLine();
         while(!sentence.equals("quit")){
             output.println(sentence);
             sentence=input.nextLine();      
             }
         output.close();
         Scanner out=new Scanner(file);
         while(out.hasNextLine()){
             String[] check=out.nextLine().split(" ");
             line++;
             cha+=2;
             word+=check.length;
         }    
             System.out.println("Total characters : "+(file.length()-cha));
             System.out.println("Total words : "+word);
             System.out.println("Total lines : "+line);
             
         
    }
    
}
