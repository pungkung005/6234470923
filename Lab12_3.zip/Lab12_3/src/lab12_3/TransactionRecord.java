
package lab12_3;

import java.util.Scanner;

public class TransactionRecord {
     private int account_number=0;
     private double amount_of_transaction=0;
     public TransactionRecord(int account_number,double amount_of_transaction ){
         this.account_number=account_number;
         this.amount_of_transaction=amount_of_transaction;    
     }

    TransactionRecord(Scanner rmfile) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
     public int get_an(){
         return account_number;
     }
     public double get_aot(){
         return amount_of_transaction;
     }
     
}
