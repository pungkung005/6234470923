
package lab12_3;

import java.util.Scanner;

public class AccountRecord {
 private int acctNo;
 private String name;
 private double balance;
 private int cnt;
 private int transCnt = 0; // นับว่า บัญชีนี ้ท ารายการ transaction ไปกี่ครั้ง
 public AccountRecord (int acctNo, String name, double balance) {
 this.acctNo = acctNo;
 this.name = name;
 this.balance = balance;
 cnt++;
 }

    AccountRecord(Scanner rtfile) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 public int getAcctNo() { return acctNo; }
 public String getName() { return name; }
 public double getBalance(){ return balance; }
 public int getTransCnt() { return transCnt; }
 public int getcnt(){return cnt;}
 public void combine(TransactionRecord t){
     if (t.get_an() == acctNo){
     balance+=t.get_an();
     transCnt++;}
 }
}