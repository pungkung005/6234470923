
package lab11_2;

public class Pool extends Terrain{
    public Pool(String name) { 
        super(name);     
    }     
    public boolean canMove(Animal animal) {
        if(animal instanceof CanFly)
            return true;
        return false;     
    }
}
