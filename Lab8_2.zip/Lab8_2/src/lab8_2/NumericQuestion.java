
package lab8_2;

/**
 *
 * @author User
 */
public class NumericQuestion extends Question{
    public NumericQuestion(String text){
        super(text);
    }
    @Override
    public boolean checkAnswer(String response){
        return (Double.valueOf(response)-0.01)<= Double.valueOf(answer) && Double.valueOf(answer) <=(Double.valueOf(response)+0.01);
    
}
}
