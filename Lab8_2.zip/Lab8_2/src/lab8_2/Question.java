
package lab8_2;

/**
 *
 * @author User
 */
public class Question {
    public String text;
    public String answer;
    
    public Question(){
        
    }
    public Question(String text){
        this.text=text;
    }
    public void  setText(String text){
        this.text=text;
    }
    public void setAnswer(String answer){
        this.answer=answer;
    }
    public String getAnswer(){
        return answer;
    }
    public String getText(){
        return text;
    }
    public boolean checkAnswer(String check){
        return check==answer;
    }
    public void display(){
        System.out.println(text);
    }
}
