package lab10_1;

public class Subject implements Evaluation{
    private String subjName;
    private int[] score;
    public Subject(String name,int[] subjscore){
        this.score=subjscore;
        this.subjName=name;
    }
    @Override
    public double evaluate() {
        double sumn=0;
    for(int i=0;i<score.length;i++){
        sumn=sumn+score[i];
    }
    sumn=sumn/score.length;
    return sumn;
    }

    @Override
    public char grade(double a) {
        if (a>=70){
            return 'P';
        }
        else{
            return 'F';
        }
    }
    
    public String toString(){
        return subjName;
    } 
    
    
    
}
