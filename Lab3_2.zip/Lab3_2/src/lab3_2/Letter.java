package lab3_2;
public class Letter {
    private String text,strfrom,strto,endtext;
    public Letter(String from, String to){
        strfrom= from;
        strto=to;
        text="";
    }
    public void addLine(String line){
        text=text+"\n"+line;
    }
    
    public String getText(){
        endtext="Dear"+strfrom+":"+"\n"+text+"\n\n"+strto;
        return endtext;
    } 
}
