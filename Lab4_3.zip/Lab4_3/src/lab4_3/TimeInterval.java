
package lab4_3;

public class TimeInterval {
    private float time,endtime,hour,min;
    
    public TimeInterval (float time,float endtime){
        this.time=time;
        this.endtime=endtime;
    }
    
    public float getMinutes(){
        min=(endtime%100)-(time%100);
        if (min<0){
            min=min+60;
            }
        return min;
    }    
    
    public float getHours(){
        hour=(endtime/100)-(time/100);
        
        return hour;
    }
        
    
}
