
package lab4_3;
import java.util.Scanner;
public class TimeIntervalTester {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter start time: ");
        float time=input.nextFloat();
        System.out.print("Enter end time: ");
        float endtime=input.nextFloat();
        
        TimeInterval sum= new TimeInterval(time,endtime);
        System.out.print((int)sum.getHours()+" hours "+(int)sum.getMinutes()+" minutes");
    }
    
}
