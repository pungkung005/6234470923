package lab7_2;

public class MagicSquare {
    
    private int square[][];
    
    public MagicSquare(int a) {
        square = new int[a][a];
        int b = 1;
        square[a-1][(a-1)/2] = 1;
        while(b<a*a) {
            for (int i=0; i<square.length; i++) {
                for (int j=0; j<square[i].length; j++) {
                    if (square[i][j] == b) {
                        b++;
                        if (i+1 < a && j+1 < a) {
                            if (square[i+1][j+1] != 0) {
                                square[i-1][j] = b;
                            }
                            else {
                                square[i+1][j+1] = b;
                            }
                        }
                        else if (i+1 >= a && j+1 < a){
                            square[0][j+1] = b;
                        }
                        else if (j+1 >= a && i+1 < a) {
                            square[i+1][0] = b;
                        }
                        else if (i == a-1 && j == a-1) {
                            square[i-1][j] = b;
                        }
                    }
                }
            }
        }
    }
    
    public String toString() {
        String string = "";
        for (int i = 0; i < square.length; i++) {
            for (int j = 0; j < square[i].length; j++) {
                if (j == square[i].length - 1) {
                    string = string + square[i][j];
                }
                else {
                    string = string + square[i][j] + "\t";
                }
            }
            if (!(i == square.length - 1)) {
                string = string + "\n\n";
            }
        }
        return string;
    }
}