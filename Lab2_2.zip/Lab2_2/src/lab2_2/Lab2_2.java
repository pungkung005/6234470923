package lab2_2;
public class Lab2_2 {
    public static void main(String[] args) {
    String hello = "Hello, World!";
    String hello1 = hello.replace("e","z").replace("o","e").replace("z","o");
    System.out.println(hello1);
    }
}