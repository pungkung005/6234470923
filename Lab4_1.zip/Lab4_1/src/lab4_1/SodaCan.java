package lab4_1;
public class SodaCan {
    private float diameter,area,volume,height;

    public SodaCan(float height,float diameter) {
        this.diameter=diameter;
        this.height=height;
    }
    
    public float getVolume(){
        volume=(float)(Math.PI*(Math.pow((diameter/2),2))*height);
        return volume;
    }
    public float getSurfaceArea(){
        area=(float)((2*Math.PI*(diameter/2)*height)+(2*Math.PI*(Math.pow((diameter/2),2))));
        return area;
    }
}