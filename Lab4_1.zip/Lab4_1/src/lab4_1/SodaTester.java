package lab4_1;
import java.util.Scanner;
public class SodaTester {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter height:");
        float height=input.nextFloat();
        System.out.print("Enter diameter:");
        float diameter=input.nextFloat();
        
        SodaCan sum = new SodaCan(height,diameter);
        System.out.printf("Volume: %.2f",sum.getVolume());
        System.out.printf("\nSurface area: %.2f",sum.getSurfaceArea());
    }
    
}