package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue{
    private int i = 0;
    private ArrayList<String> m = new ArrayList<String>();
    public MusicBox(){
    }
    public void enqueue(String o){
        m.add(o);
        System.out.println(o+" is added in queue");
    }
    public void dequeue(){
        if(i<m.size()){
            System.out.println("Now playing "+m.get(i));
            i++;
        }
        else{
            System.out.println("There are not Music in list");
        }
    }
    public void enqueue(Object o) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
